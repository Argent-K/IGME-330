class Favorite {
    constructor(fid, text, url, comments){
        this.fid = fid;
        this.text = text;
        this.url = url;
        this.comments = comments;
    }
}

export {Favorite};